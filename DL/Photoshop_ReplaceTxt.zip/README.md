# Ps-ReplaceTxt
Gather and replace all text layers in a Adobe Photoshop file

## Installation

1. Depending on your preferred language, put the respecting .jsx file inside  
`[Your Photoshop Installation Folder]/Presets/Scripts/`  
(For English, use `Xquid-ReplaceTxt_en.jsx`,  
For Chinese(Traditional), use `Xquid-ReplaceTxt_zh-tw.jsx`)  
1. Restart Photoshop (if it is opened).

## Usage

1. After installing, open a .psd file with some text layers in it.
1. You should find the script in `Files->Automation->Replace Texts...`(English version), or `檔案->自動->取代文字...` for the Chinese version.

