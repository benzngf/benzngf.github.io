bl_info = {
    "name": "Offset Keys by Hierarchy",
    "author": "Xquid Zhuang",
    "version": (1, 0),
    "blender": (2, 80, 0),
    "location": "DopeSheet > Key > Transform > Offset Keys by Hierarchy",
    "description": "Offset keys according to parent hierarchy",
    "warning": "",
    "doc_url": "https://xquid.work/Tools/Blender_OffsetKeys.html",
    "category": "Animation",
}


import bpy
from bpy.types import Operator
from mathutils import Vector


class DopeSheet_Offset_Keys(Operator):
    """Offset keys according to parent hierarchy"""
    bl_idname = "anim.keyframe_offset_hierarchy"
    bl_label = "Offset Keys by Hierarchy"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        offset = (self.mouse_x - self.init_mouse_x) - self.last_offset
        self.last_offset = (self.mouse_x - self.init_mouse_x)
        try:
            for i,carr in self.curves_by_hiearchy.items():
                delta = offset * (i-self.min_hiearchy_ind) * 0.05
                for fcu in carr:
                    for k in fcu.keyframe_points:
                        if k.select_control_point:
                            k.co[0] += delta
                            k.handle_left[0] += delta
                            k.handle_right[0] += delta
        except:
            print('error')
        return {'FINISHED'}
    
    def modal(self, context, event):
        print(str(event.type))
        if event.type == 'MOUSEMOVE':  # Apply
            self.mouse_x = event.mouse_x
            self.execute(context)
        elif event.type == 'LEFTMOUSE' or event.type == 'RET':  # Confirm
            return {'FINISHED'}
        elif event.type in {'RIGHTMOUSE', 'ESC'}:  # Cancel
            return {'CANCELLED'}
        return {'RUNNING_MODAL'}
    
    def get_hiearchy_index(self, obj, bonename):
        if bonename and obj.type == 'ARMATURE':
            hiearchylen = len(obj.data.bones[bonename].parent_recursive)
            return 1 + hiearchylen + self.get_hiearchy_index(obj, None)
        elif obj.parent:
            return 1 + self.get_hiearchy_index(obj.parent, obj.parent_bone)
        return 0
    
    def fcurve_has_selected_key(self,fcurve):
        for k in fcurve.keyframe_points:
            if k.select_control_point:
                return True
        return False
    
    def invoke(self, context, event):
        self.init_mouse_x = event.mouse_x
        self.mouse_x = event.mouse_x
        self.last_offset = 0
        #construct data to manipulate
        self.curves_by_hiearchy = {}
        self.min_hiearchy_ind = -1
        objs = [o for o in context.scene.objects if o.animation_data]
        for o in objs:
            ind = 0
            if o.type == 'ARMATURE':
                for fcu in o.animation_data.action.fcurves:
                    if self.fcurve_has_selected_key(fcu):
                        if 'bones["' in fcu.data_path: #this is a bone curve
                            bonename = fcu.data_path.split('"')[1]
                            ind = self.get_hiearchy_index(o,bonename)
                            if not ind in self.curves_by_hiearchy:
                                self.curves_by_hiearchy[ind] = []
                                if self.min_hiearchy_ind < 0 or ind < self.min_hiearchy_ind:
                                    self.min_hiearchy_ind = ind
                            self.curves_by_hiearchy[ind].append(fcu)
                        else: # a normal curve in an armature object
                            ind = self.get_hiearchy_index(o,o.parent_bone)
                            if not ind in self.curves_by_hiearchy:
                                self.curves_by_hiearchy[ind] = []
                                if self.min_hiearchy_ind < 0 or ind < self.min_hiearchy_ind:
                                    self.min_hiearchy_ind = ind
                            self.curves_by_hiearchy[ind].append(fcu)
            else:
                has_selected_curve = False
                for fcu in o.animation_data.action.fcurves:
                    if self.fcurve_has_selected_key(fcu):
                        has_selected_curve = True
                        break
                if has_selected_curve:
                    ind = self.get_hiearchy_index(o,o.parent_bone)
                    #add curves to dictionary
                    if not ind in self.curves_by_hiearchy:
                        self.curves_by_hiearchy[ind] = []
                        if self.min_hiearchy_ind < 0 or ind < self.min_hiearchy_ind:
                            self.min_hiearchy_ind = ind
                    self.curves_by_hiearchy[ind].extend(o.animation_data.action.fcurves)
        self.execute(context)
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}


# Registration
def add_object_button(self, context):
    self.layout.operator(
        DopeSheet_Offset_Keys.bl_idname,
        text="Offset Keys by Hierarchy",
        icon='ARMATURE_DATA')


# This allows you to right click on a button and link to documentation
def add_object_manual_map():
    url_manual_prefix = "https://xquid.work/"
    url_manual_mapping = (
        ("bpy.ops.anim.keyframe_offset_hierarchy", "Tools/Blender_OffsetKeys.html"),
    )
    return url_manual_prefix, url_manual_mapping

def register():
    bpy.utils.register_class(DopeSheet_Offset_Keys)
    bpy.utils.register_manual_map(add_object_manual_map)
    bpy.types.DOPESHEET_MT_key_transform.append(add_object_button)


def unregister():
    bpy.utils.unregister_class(DopeSheet_Offset_Keys)
    bpy.utils.unregister_manual_map(add_object_manual_map)
    bpy.types.DOPESHEET_MT_key_transform.remove(add_object_button)


#if __name__ == "__main__":
    #register()
    #bpy.ops.keys.offset('INVOKE_DEFAULT')
